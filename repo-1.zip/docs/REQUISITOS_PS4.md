# O que precisa estar no PS4

> Os dois .sprx são uma SUSPEITA, ainda não confirmada: outros ports 2D com SDL2 rodam sem eles.
> Só passam a ser obrigatórios se o log do app provar isso.

Nada disso vai para o GitHub: são arquivos do jogo e binários da Sony.

| O quê | Onde no PS4 |
| --- | --- |
| Pasta do Pizza Tower (com o mod de ícones aplicado no data.win) | /data/pizza-tower/ |
| libScePigletv2VSH.sprx (744.208 bytes) | /data/self/system/common/lib/ |
| libSceShaccVSH.sprx (10.394.272 bytes) | /data/self/system/common/lib/ |
| O .pkg gerado pelo workflow | /data/pkg/ e instalar pelo Package Installer do GoldHEN |

## Por que os dois .sprx
O vídeo do PS4 via SDL usa a biblioteca gráfica Piglet da Sony, e o firmware de varejo a traz sem o
compilador de shaders. Os ports de PS4 que usam SDL/OpenGL ES (Super Mario 64, Ship of Harkinian etc.)
usam esse par de módulos. Se você já roda algum deles, os dois arquivos já estão na pasta certa.

## Cuidados com o FTP
- Servidor FTP do GoldHEN: porta 2121, usuário e senha vazios.
- Envie os .sprx em modo BINÁRIO. Em modo texto o arquivo corrompe (erro 0x8002000D no log).
- Confira o tamanho depois de enviar: tem que bater com a tabela acima.

## Onde olhar quando algo falha
/data/pizza-tower/log.txt (cada execução sobrescreve o anterior; copie antes de abrir o app de novo).
